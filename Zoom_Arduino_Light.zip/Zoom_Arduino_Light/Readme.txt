********* WALID BENMOHAMED *********
*** walid.benmohamed@alithya.com ***

Arduino Zoom Light V 1.0
===========
C'est un module permet de vérifier le statut de profils Zoom, et avoir une notification lumière sur les Leeds de circuit Arduino avec différentes couleurs selon le statut de profil détecté:
* Couleur vert si le statut de profil est disponible
* Couleur Jaune si l'utilisateur loin de Zoom
* Couleur Rouge si l'utilisateur occupé avec un appel ou avec un meeting room

## Ouvrire le code source 

* Installez le Driver de Arduino CH341SER trouvé sous "Arduino Zoom Light\CH341SER\SETUP.EXE"
* Installer Visual Studio 2017 community
* Telecharger le dossier "Zoom_Arduino_Light" sur votre poste de travail
* Ouvrire le code source en cliquent sur "Zoom_Arduino_Light.sln"
* Brachez le module dans le port USB disponible
* Apres le demarrage correcte de visual studio et l'ouverture de code source vous pouvez maintenant executer l'aplication pour le tester ou modifier le code source




## Installation de module

* Installez le Driver de Arduino CH341SER trouvé sous "Arduino Zoom Light\CH341SER\SETUP.EXE"
* Copiez le Dossier "Debug" qui se trouve sous "..\Zoom_Arduino_Light\Light_Notification\bin"
* Coller le Dossier "Debug" sous "C:\Program Files\"
* Faire une raccourcie sur le bureau pour le .exe "Light_Notification.exe"
* Brachez le module dans le port USB disponible
* lancez le module par le double clique de notre raccourciesur bureau "Light_Notification.exe"

*************************************
*************************************
******* Quebec le 04/12/2019 ********


