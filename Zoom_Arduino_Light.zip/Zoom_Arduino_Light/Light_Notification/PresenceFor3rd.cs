﻿

namespace Light_Notification
{
    public enum PresenceFor3rd
    {
        PresenceFor3rd_Unknown,
        PresenceFor3rd_Online,
        PresenceFor3rd_IncomingCall,
        PresenceFor3rd_InMeeting,
        PresenceFor3rd_DND,
        PresenceFor3rd_Offline,
        PresenceFor3rd_Away,
    }
}
