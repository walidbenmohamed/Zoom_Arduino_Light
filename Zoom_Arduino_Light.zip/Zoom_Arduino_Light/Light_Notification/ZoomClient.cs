﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace Light_Notification
{
    public class ZoomClient
    {
        private ZoomClientSDK.ZoomNotificationDelegate fp;

        private event Action<PresenceFor3rd> onPresenceReceived;

        public event Action<PresenceFor3rd> OnPresenceReceived
        {
            add
            {
                if (this.onPresenceReceived != null && ((IEnumerable<Delegate>)this.onPresenceReceived.GetInvocationList()).Contains<Delegate>((Delegate)value))
                    return;
                this.onPresenceReceived += value;
            }
            remove
            {
                this.onPresenceReceived -= value;
            }
        }

        public void ConnectToZoom()
        {
            try
            {
                if (this.fp == null)
                {
                    this.fp = new ZoomClientSDK.ZoomNotificationDelegate(this.ZoomPresenceNotificationReceived);
                    ZoomClientSDK.SetIMPresenceCallBack(this.fp);
                }
                ZoomClientSDK.GetSDKAvailableFeatures();
                ZoomClientSDK.RegisterMsg(1L);
                ZoomClientSDK.GetIMPresenceStatus();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("ZoomClient: Exception in ConnectToZoom: " + (object)ex);
            }
        }

        public void GetPresenceStatus()
        {
            ZoomClientSDK.GetIMPresenceStatus();
        }

        private void ZoomPresenceNotificationReceived(IntPtr msg)
        {
            try
            {
                IMPresenceData structure = Marshal.PtrToStructure<IMPresenceData>(msg);
                if (this.onPresenceReceived == null)
                    return;
                this.onPresenceReceived(structure.status);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("ZoomClient: Exception in ZoomPresenceNotificationReceived: " + (object)ex);
            }
        }

        public void Terminate()
        {
            ZoomClientSDK.DestroySdkChannel();
        }
    }
}
