﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Management;
using System.Management.Instrumentation;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.IO;
using System.IO.Ports;
using ZOOM_SDK_DOTNET_WRAP;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace Light_Notification
{
    public partial class Zoom_Light : Form
    {
        private static Zoom_Light me = (Zoom_Light)null;
        public ZoomClient zc = (ZoomClient)null;
        public Zoom_Light()
        {
            InitializeComponent();
        }
        //Decalaration
        #region Declaration
        public SerialPort serialPort;
        string VER_Command;
        #endregion
        //Lecture de Port existant
        public void responseHandler(object sender, SerialDataReceivedEventArgs args)
        {
            string x = serialPort.ReadExisting();
        }
        private void Zoom_Light_Load(object sender, EventArgs e)
        {
            this.label6.BackColor = Color.LightBlue;
            serialPort = new SerialPort();
            string[] ports = SerialPort.GetPortNames();
            // Display each port name to the console.
            foreach (string port in ports)
            {
                serialPort.PortName = port;
            }
            serialPort.DataBits = 8;
            serialPort.Parity = Parity.None;
            serialPort.StopBits = StopBits.One;
            serialPort.BaudRate = 9600;
            //connection Zoom et Verification status
            #region connection Zoom et Verification status
            this.zc = new ZoomClient();
            this.zc.OnPresenceReceived += new Action<PresenceFor3rd>(this.Zc_OnPresenceReceived);
            this.zc.ConnectToZoom();
            #endregion
        }
        //Close Port
        #region Close Port
        private void Close_Click(object sender, EventArgs e)
        {
            if (serialPort is SerialPort)
            {
                try
                {
                    if (MessageBox.Show(this, "Etes-vous sûr de vouloir fermer la module? (Vous pouvez le réduire au lieu de le fermer définitivement)", "ATTENTION !!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    {
                        string VER_Command = "w";
                        serialPort.Open();
                        serialPort.DiscardOutBuffer();
                        serialPort.DiscardInBuffer();
                        serialPort.DataReceived += new SerialDataReceivedEventHandler(responseHandler);
                        serialPort.Write(VER_Command);
                        this.PortNamelab.BackColor = Color.Black;
                        this.PortNamelab.Size = new Size(368, 207);
                        Close();
                    }
                }
                catch (Exception)
                {
                    throw;
                }// end CATCH portion of TRY/CATCH block
            }// end IF serialPort is viable
        }
        #endregion
        //NotifyIcon
        #region NotifyIcon
        private void Zoom_Light_SizeChanged(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                notifyIcon1.BalloonTipText = "Cliquer ici pour plus Info";
                notifyIcon1.ShowBalloonTip(1000);
                this.ShowInTaskbar = false;
                notifyIcon1.Visible = true;
            }
        }
        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            if (this.WindowState == FormWindowState.Normal)
            {
                this.ShowInTaskbar = true;
                notifyIcon1.Visible = false;
            }
        }       
        #endregion 
        //ZoomClientSDK
        #region ZoomClientSDK
        public void Zc_OnPresenceReceived(PresenceFor3rd obj)
        {
            switch (obj)
            {
                case PresenceFor3rd.PresenceFor3rd_Unknown:
                    //port fermé
                    VER_Command = "w";
                    if (serialPort is SerialPort)
                    {
                        try
                        {
                            this.PortNamelab.BackColor = Color.Black;
                            this.PortNamelab.Size = new Size(368, 207);
                            MessageBox.Show("Impossible de lancer le module! Le Port est Fermé!, branché autre fois le cable USB et rélancer le module :)");
                            //Close();
                        }
                        catch (Exception)
                        {
                        }
                        finally
                        {
                            serialPort.Close();
                        }// end CATCH portion of TRY/CATCH block
                    }// end IF serialPort is viable
                    break;
                case PresenceFor3rd.PresenceFor3rd_Online:
                    //Notification Vert si Profil connecté
                    VER_Command = "g";
                    if (serialPort is SerialPort)
                    {
                        try
                        {
                            serialPort.Open();
                            serialPort.DiscardOutBuffer();
                            serialPort.DiscardInBuffer();
                            label1.Text = "Numéro de port:  " + serialPort.PortName;
                            label5.Text = "Statut de profile: Utilisateur est connecté";
                            label5.Size = new Size(311, 115);
                            this.PortNamelab.BackColor = Color.Green;
                            this.PortNamelab.Size = new Size(368, 207);
                            serialPort.DataReceived += new SerialDataReceivedEventHandler(responseHandler);
                            serialPort.Write(VER_Command);
                            //MessageBox.Show("Zoom Profile Connected");
                            //Close();
                        }
                        catch (Exception)
                        {
                        }
                        finally
                        {
                            serialPort.Close();
                        }// end CATCH portion of TRY/CATCH block
                    }// end IF serialPort is viable                    
                    break;
                case PresenceFor3rd.PresenceFor3rd_IncomingCall:
                    //Notification Blue
                    VER_Command = "r";
                    if (serialPort is SerialPort)
                    {
                        try
                        {
                            serialPort.Open();
                            serialPort.DiscardOutBuffer();
                            serialPort.DiscardInBuffer();
                            label1.Text = "Numéro de port:" + serialPort.PortName;
                            label5.Text = "Statut de profile: Utilisateur occupé par un appel";
                            label5.Size = new Size(311, 115);
                            this.PortNamelab.BackColor = Color.Red;
                            this.PortNamelab.Size = new Size(368, 207);
                            serialPort.DataReceived += new SerialDataReceivedEventHandler(responseHandler);
                            serialPort.Write(VER_Command);
                            //MessageBox.Show("Yellow Color");
                            //Close();
                        }
                        catch (Exception)
                        {
                        }
                        finally
                        {
                            serialPort.Close();
                        }// end CATCH portion of TRY/CATCH block
                    }// end IF serialPort is viable
                    break;
                case PresenceFor3rd.PresenceFor3rd_InMeeting:
                    //Notification Violet
                    VER_Command = "r";
                    if (serialPort is SerialPort)
                    {
                        try
                        {
                            serialPort.Open();
                            serialPort.DiscardOutBuffer();
                            serialPort.DiscardInBuffer();
                            label1.Text = "Numéro de port:" + serialPort.PortName;
                            label5.Text = "Statut de profile: Utilisateur occupé pour un conférence audio";
                            label5.Size = new Size(311, 115);
                            this.PortNamelab.BackColor = Color.Red;
                            this.PortNamelab.Size = new Size(368, 207);
                            serialPort.DataReceived += new SerialDataReceivedEventHandler(responseHandler);
                            serialPort.Write(VER_Command);
                            //MessageBox.Show("Purple Color");
                            //Close();
                        }
                        catch (Exception)
                        {
                        }
                        finally
                        {
                            serialPort.Close();
                        }// end CATCH portion of TRY/CATCH block
                    }// end IF serialPort is viable
                    break;
                case PresenceFor3rd.PresenceFor3rd_DND:
                    //Notification Rouge  
                    VER_Command = "r";
                    if (serialPort is SerialPort)
                    {
                        try
                        {
                            serialPort.Open();
                            serialPort.DiscardOutBuffer();
                            serialPort.DiscardInBuffer();
                            label1.Text = "Numéro de port:  " + serialPort.PortName;
                            label5.Text = "Statut de profile: Utilisateur occupé, ne pas déranger";
                            label5.Size = new Size(311, 115);
                            this.PortNamelab.BackColor = Color.Red;
                            this.PortNamelab.Size = new Size(368, 207);
                            serialPort.DataReceived += new SerialDataReceivedEventHandler(responseHandler);
                            serialPort.Write(VER_Command);
                            //MessageBox.Show("Profil Do Not Disturb");
                            //Close();
                        }
                        catch (Exception)
                        {
                        }
                        finally
                        {
                            serialPort.Close();
                        }// end CATCH portion of TRY/CATCH block
                    }// end IF serialPort is viable
                    break;
                case PresenceFor3rd.PresenceFor3rd_Offline:
                    VER_Command = "w";
                    if (serialPort is SerialPort)
                    {
                        try
                        {
                            serialPort.Open();
                            serialPort.DiscardOutBuffer();
                            serialPort.DiscardInBuffer();
                            serialPort.DataReceived += new SerialDataReceivedEventHandler(responseHandler);
                            serialPort.Write(VER_Command);
                            this.PortNamelab.BackColor = Color.Black;
                            this.PortNamelab.Size = new Size(368, 207);
                            //serialPort.Close();
                            //MessageBox.Show("Port is Closed");
                            //Close();
                        }
                        catch (Exception)
                        {
                            throw;
                        }// end CATCH portion of TRY/CATCH block
                    }// end IF serialPort is viable
                    break;
                case PresenceFor3rd.PresenceFor3rd_Away:
                    //Notification Jaune
                    VER_Command = "y";
                    if (serialPort is SerialPort)
                    {
                        try
                        {
                            serialPort.Open();
                            serialPort.DiscardOutBuffer();
                            serialPort.DiscardInBuffer();
                            label1.Text = "Numéro de port:  " + serialPort.PortName;
                            label5.Text = "Statut de profile: Utilisateur loin de Zoom Actuellement";
                            label5.Size = new Size(311, 115);
                            this.PortNamelab.BackColor = Color.Yellow;
                            this.PortNamelab.Size = new Size(368, 207);
                            serialPort.DataReceived += new SerialDataReceivedEventHandler(responseHandler);
                            serialPort.Write(VER_Command);
                            //MessageBox.Show("Profil Away");
                            //Close();
                        }
                        catch (Exception)
                        {
                        }
                        finally
                        {
                            serialPort.Close();
                        }// end CATCH portion of TRY/CATCH block
                    }// end IF serialPort is viable
                    break;
            }
        }

        #endregion

       
    }
}
