﻿


namespace Light_Notification
{
    internal struct IMPresenceData
    {
        public bool bResult;
        public int errorCode;
        public PresenceFor3rd status;
    }
}
