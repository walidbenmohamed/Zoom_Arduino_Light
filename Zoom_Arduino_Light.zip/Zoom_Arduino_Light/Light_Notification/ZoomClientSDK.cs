﻿using System;
using System.Runtime.InteropServices;

namespace Light_Notification
{
    class ZoomClientSDK
    {
        [DllImport("ZoomClientSDK.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int DestroySdkChannel();

        [DllImport("ZoomClientSDK.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int GetSDKAvailableFeatures();

        [DllImport("ZoomClientSDK.dll", CallingConvention = CallingConvention.Cdecl)]
        internal static extern void SetIMPresenceCallBack(
        ZoomClientSDK.ZoomNotificationDelegate functionCallback);

        [DllImport("ZoomClientSDK.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Cdecl, SetLastError = true)]
        internal static extern bool RegisterMsg(long features);

        [DllImport("ZoomClientSDK.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int GetIMPresenceStatus();

        [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
        internal delegate void ZoomNotificationDelegate(IntPtr msg);


        [DllImport("meeting_participants_ctrl_interface.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int GetUserName();
    }
}
